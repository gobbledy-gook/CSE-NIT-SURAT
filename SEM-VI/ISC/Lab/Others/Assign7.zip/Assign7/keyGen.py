import sympy as s
import math as m
import random

def generate_large_prime_numbers(b):
    prime1 = s.randprime(2**(b-1), 2**b)
    prime2 = s.randprime(2**(b-1), 2**b)
    return prime1, prime2

def keyGen(n):
    phiN = s.totient(n)
    print("ø(n) = ", phiN)
    e = random.randint(1, phiN)
    while(m.gcd(e, phiN) != 1):
        e = random.randint(1, phiN)
    return e  

def privateKey(n, e):
    phiN = s.totient(n) 
    d = s.mod_inverse(e, phiN)
    return d

def encryption(n, e, msg):
    m = ""
    for ch in msg:
        m+= str(ord(ch)-65)
    m = int(m) 
    print("Message: ", m)   
    c = pow(m, e, n)
    return c

def decryption(n, d, msg):
    d = pow(msg, d, n)
    print("Decrypted message", d)
    d = str(d)
    msgd = ""
    for i in range(0, len(d)-1, 2):
        msgd += chr(int(d[i:i+2])+65)
    return msgd

b = int(input("Enter the bit size for RSA Key Generation: "))
p,q = generate_large_prime_numbers(b)
print("p: ", p, "\n\nq: ", q)
n = p*q

e = keyGen(n)
print("RSA Public Key ({pubE}, {N})".format(pubE = e, N =n))

d = privateKey(n, e)
print("RSA Private Key ({prD}, {N})".format(prD = d, N =n))

msg = input("Enter message: ")
c = encryption(n, e, msg)
print("Encrypted Message: ", c)

d = decryption(n, d, c)
print("Decrypted Message: ", d)